package com.mx.accessibilitydemo;

import com.mx.accessibilitydemo.ExcelUtli.Excel_To_Info_TXT;

import org.junit.Test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void test() {
        Excel_To_Info_TXT excel = new Excel_To_Info_TXT();
        boolean yz = excel.PlanA(3,";","法定代表人","电话","其他电话","D:\\test2.xlsx","D:\\info.txt");
        if (yz){
            System.out.println("ok");
        }else {
            System.out.println("error");
        }
    }

    @Test
    public void test2(){

    }
}