package com.mx.accessibilitydemo;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.mx.accessibilitydemo.ExcelUtli.Excel_To_Info_TXT;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private ActivityResultLauncher<String> mFileChoose;
    private String path;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView tvFilePath = findViewById(R.id.tv_file_path);
        mFileChoose = registerForActivityResult(new ActivityResultContracts.GetContent(), result -> {
            path = "文件路径：" + GetFilePathFromUri.getPath(this, result);
            tvFilePath.setText(path);
        });
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            }
        }
        findViewById(R.id.btn_open_accessibility).setOnClickListener(view -> {
            if (!isOpenAccessibility()) {
                Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } else {
                Toast.makeText(MainActivity.this, "已经开启无障碍", Toast.LENGTH_SHORT).show();
            }
        });
        findViewById(R.id.btn_close).setOnClickListener(v -> {
            AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this)
                    .setTitle("提示")
                    .setMessage("请确认是否退出？")
                    .setNegativeButton("取消", null)
                    .setPositiveButton("退出", (dialog, which) -> finish())
                    .create();
            alertDialog.show();
        });
//        application/vnd.openxmlformats-officedocument.spreadsheetml.sheet
//        application/vnd.ms-excel
        findViewById(R.id.btn_select_file).setOnClickListener(v -> mFileChoose.launch("*/*"));
        Button btnCopyID = findViewById(R.id.btn_copy_id);
        btnCopyID.setOnClickListener(v -> {
            String id = Settings.System.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            ClipboardManager manager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            ClipData clipData = ClipData.newPlainText("id", id);
            manager.setPrimaryClip(clipData);
            Toast.makeText(MainActivity.this, "ID已复制到剪切板", Toast.LENGTH_SHORT).show();
        });
        EditText et_info = findViewById(R.id.et_info);
        findViewById(R.id.btn_get_info).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String info = et_info.getText().toString();
                Excel_To_Info_TXT getInfo_txt = new Excel_To_Info_TXT();
                String[] split = info.split("\\.");
                boolean yz = false;
                if (split.length == 5) {
                    path = path.replace("文件路径：", "");
                    String filePath = getExternalFilesDir("").getAbsolutePath() + "/info.txt";
                    yz = getInfo_txt.PlanA(Integer.parseInt(split[0]), split[1], split[2], split[3], split[4], path, filePath);
                } else if (split.length == 4) {
                    String filePath = getExternalFilesDir("").getAbsolutePath() + "/info.txt";
                    yz = getInfo_txt.PlanB(Integer.parseInt(split[0]), split[1], split[2], split[3], path, filePath);
                } else {
                    yz = false;
                }

                if (yz) {
                    Toast.makeText(MainActivity.this, "获取成功", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "获取失败", Toast.LENGTH_SHORT).show();
                }
            }
        });
        new Thread(() -> {
            String id = Settings.System.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            String content = HttpUtil.get("https://www.yuque.com/api/docs/share/5faa5b6a-e103-414a-bbdd-8f2c62b58c23?doc_slug=nilgwr&from=https%3A%2F%2Fwww.yuque.com%2Fdocs%2Fshare%2F5faa5b6a-e103-414a-bbdd-8f2c62b58c23%3F%23");
            try {
                JSONObject jsonObject = new JSONObject(content);
                JSONObject data = jsonObject.getJSONObject("data");
                String description = data.getString("description");
                if (description.contains(id)) {
                    btnCopyID.post(() -> {
                        btnCopyID.setVisibility(View.GONE);
                        Toast.makeText(this, "您已拥有使用权限", Toast.LENGTH_SHORT).show();
                    });
                } else {
                    btnCopyID.post(() ->
                            Toast.makeText(MainActivity.this, "请联系作者获取使用权限", Toast.LENGTH_SHORT).show());
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }).start();
    }

    /**
     * 判断是否开启无障碍服务权限
     */
    private boolean isOpenAccessibility() {
        AccessibilityManager accessibilityManager =
                (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
        return accessibilityManager.isEnabled();
    }
}