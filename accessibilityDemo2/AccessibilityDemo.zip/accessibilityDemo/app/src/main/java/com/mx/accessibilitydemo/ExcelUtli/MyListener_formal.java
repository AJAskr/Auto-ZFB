package com.mx.accessibilitydemo.ExcelUtli;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
//import com.mx.accessibilitydemo.ExcelUtli.MyData_formal;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MyListener_formal extends AnalysisEventListener<MyData_formal> {
    //存储数据和表头信息的列表
    List<MyData_formal> list = new ArrayList<>();
    List<Map<Integer,String>> list2 = new ArrayList<>();
    @Override
    public void invoke(MyData_formal data, AnalysisContext context) {
        System.out.println(data);
        list.add(data);
    }

    @Override
    public void invokeHeadMap(Map<Integer, String> headMap, AnalysisContext context) {
        System.out.println("表头信息: "+headMap);
        list2.add(headMap);
    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext context) {
        System.out.println("读取完毕");
    }
    //返回两个list
    public List<Map<Integer, String>> getList2() {
        return list2;
    }

    public List<MyData_formal> getList() {
        return list;
    }
}
