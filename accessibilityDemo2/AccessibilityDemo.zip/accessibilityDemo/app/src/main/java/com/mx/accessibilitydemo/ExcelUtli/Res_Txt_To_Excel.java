package com.mx.accessibilitydemo.ExcelUtli;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.read.builder.ExcelReaderBuilder;
import com.alibaba.excel.read.builder.ExcelReaderSheetBuilder;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Res_Txt_To_Excel {
    //根据Res.txt得到的结果文本把预处理表格进行最后的结果筛选

    /**
     * @param resPath    结果文件路径
     * @param advTxtPath adv文件路径
     * @param savePath   表格最后1的保存路径
     * @return 返回真假
     */
    public boolean ResToExcel(String resPath, String advTxtPath, String savePath) {
        //将res.txt的数据保存到list
        File file = new File(resPath);
        List<String> resData = new ArrayList<>();
        if (!file.exists()) {
            return false;
        }
        try {
            FileReader fw = new FileReader(file);
            BufferedReader br = new BufferedReader(fw);
            String line = null;
            while ((line = br.readLine()) != null) {
                resData.add(line);
            }
            System.out.println(resData);
        } catch (Exception e) {
            return false;
        }

        //读取info_adv.txt文本把变量存放
        String originalXLSX = "";
        int[] indexRES = new int[3];
        String[] indexXLSX_col = new String[4];
        file = new File(advTxtPath);
        if (!file.exists()) {
            return false;
        }
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line = "";
            int cnt = 0;
            while ((line = br.readLine()) != null) {
                if (cnt == 0) originalXLSX = line;
                if (cnt == 1) {
                    String[] tempStr = line.split(";");
                    indexRES[0] = toInt(tempStr[0]);
                    indexRES[1] = toInt(tempStr[1]);
                    indexRES[2] = toInt(tempStr[2]);
                }
                if (cnt == 2) {
                    String[] tempStr = line.split(";");
                    System.arraycopy(tempStr, 0, indexXLSX_col, 0, 4);
                }
                cnt++;
            }
        } catch (Exception e) {
            return false;
        }
        //读取原xlsx文件把内容放在list
        MyListener_formal listener_formal = new MyListener_formal();
        ExcelReaderBuilder read;
        try {
            read = EasyExcel.read(originalXLSX, MyData_formal.class, listener_formal).
                    headRowNumber(toInt(indexXLSX_col[0]));
        } catch (Exception e) {
            return false;
        }
        ExcelReaderSheetBuilder sheet = read.sheet();
        sheet.doRead();

        //保存的列
        List<List<String >> resDataList = new ArrayList<>();

        for (String i : resData){
            String[] tempResData = i.split(";");
            if (tempResData[tempResData.length-1].equals("false")){

            }
        }

        //保存的表头信息
        List<List<String>> list = new ArrayList<>();
        int cnt = 0;
        for (Map<Integer, String> i : listener_formal.getList2()) {
            if (cnt == toInt(indexXLSX_col[0])) {
                for (int j = 0; j < i.size(); j++){
                    List<String> tempHead = new ArrayList<>();
                    tempHead.add(i.get(j));
                    list.add(tempHead);
                }
            }
            cnt++;
        }

        //将结果xlsx文件保存
        try {
            EasyExcel.write(savePath).head(list).sheet("sheet1").doWrite(resDataList);
        }catch (Exception e){
            return false;
        }
        return true;
    }

    public int toInt(String t) {
        return Integer.parseInt(t);
    }
}
