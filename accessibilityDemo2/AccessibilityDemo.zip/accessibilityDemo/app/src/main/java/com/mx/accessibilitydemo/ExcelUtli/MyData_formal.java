package com.mx.accessibilitydemo.ExcelUtli;

public class MyData_formal {
    private String idx1;
    private String idx2;
    private String idx3;
    private String idx4;
    private String idx5;
    private String idx6;
    private String idx7;
    private String idx8;
    private String idx9;
    private String idx10;
    private String idx11;
    private String idx12;
    private String idx13;
    private String idx14;
    private String idx15;
    private String idx16;
    private String idx17;
    private String idx18;
    private String idx19;
    private String idx20;
    private String idx21;
    private String idx22;
    private String idx23;
    private String idx24;
    private String idx25;
    private String idx26;
    private String idx27;
    private String idx28;
    private String idx29;
    private String idx30;

    public String getIdx1() {
        return idx1;
    }

    public void setIdx1(String idx1) {
        this.idx1 = idx1;
    }

    public String getIdx2() {
        return idx2;
    }

    public void setIdx2(String idx2) {
        this.idx2 = idx2;
    }

    public String getIdx3() {
        return idx3;
    }

    public void setIdx3(String idx3) {
        this.idx3 = idx3;
    }

    public String getIdx4() {
        return idx4;
    }

    public void setIdx4(String idx4) {
        this.idx4 = idx4;
    }

    public String getIdx5() {
        return idx5;
    }

    public void setIdx5(String idx5) {
        this.idx5 = idx5;
    }

    public String getIdx6() {
        return idx6;
    }

    public void setIdx6(String idx6) {
        this.idx6 = idx6;
    }

    public String getIdx7() {
        return idx7;
    }

    public void setIdx7(String idx7) {
        this.idx7 = idx7;
    }

    public String getIdx8() {
        return idx8;
    }

    public void setIdx8(String idx8) {
        this.idx8 = idx8;
    }

    public String getIdx9() {
        return idx9;
    }

    public void setIdx9(String idx9) {
        this.idx9 = idx9;
    }

    public String getIdx10() {
        return idx10;
    }

    public void setIdx10(String idx10) {
        this.idx10 = idx10;
    }

    public String getIdx11() {
        return idx11;
    }

    public void setIdx11(String idx11) {
        this.idx11 = idx11;
    }

    public String getIdx12() {
        return idx12;
    }

    public void setIdx12(String idx12) {
        this.idx12 = idx12;
    }

    public String getIdx13() {
        return idx13;
    }

    public void setIdx13(String idx13) {
        this.idx13 = idx13;
    }

    public String getIdx14() {
        return idx14;
    }

    public void setIdx14(String idx14) {
        this.idx14 = idx14;
    }

    public String getIdx15() {
        return idx15;
    }

    public void setIdx15(String idx15) {
        this.idx15 = idx15;
    }

    public String getIdx16() {
        return idx16;
    }

    public void setIdx16(String idx16) {
        this.idx16 = idx16;
    }

    public String getIdx17() {
        return idx17;
    }

    public void setIdx17(String idx17) {
        this.idx17 = idx17;
    }

    public String getIdx18() {
        return idx18;
    }

    public void setIdx18(String idx18) {
        this.idx18 = idx18;
    }

    public String getIdx19() {
        return idx19;
    }

    public void setIdx19(String idx19) {
        this.idx19 = idx19;
    }

    public String getIdx20() {
        return idx20;
    }

    public void setIdx20(String idx20) {
        this.idx20 = idx20;
    }

    public String getIdx21() {
        return idx21;
    }

    public void setIdx21(String idx21) {
        this.idx21 = idx21;
    }

    public String getIdx22() {
        return idx22;
    }

    public void setIdx22(String idx22) {
        this.idx22 = idx22;
    }

    public String getIdx23() {
        return idx23;
    }

    public void setIdx23(String idx23) {
        this.idx23 = idx23;
    }

    public String getIdx24() {
        return idx24;
    }

    public void setIdx24(String idx24) {
        this.idx24 = idx24;
    }

    public String getIdx25() {
        return idx25;
    }

    public void setIdx25(String idx25) {
        this.idx25 = idx25;
    }

    public String getIdx26() {
        return idx26;
    }

    public void setIdx26(String idx26) {
        this.idx26 = idx26;
    }

    public String getIdx27() {
        return idx27;
    }

    public void setIdx27(String idx27) {
        this.idx27 = idx27;
    }

    public String getIdx28() {
        return idx28;
    }

    public void setIdx28(String idx28) {
        this.idx28 = idx28;
    }

    public String getIdx29() {
        return idx29;
    }

    public void setIdx29(String idx29) {
        this.idx29 = idx29;
    }

    public String getIdx30() {
        return idx30;
    }

    public void setIdx30(String idx30) {
        this.idx30 = idx30;
    }

    public String[] getAllData(){
        return new String[]{getIdx1(),getIdx2(),getIdx3(),getIdx4(),getIdx5(),getIdx6(),
                getIdx7(),getIdx8(),getIdx9(),getIdx10(),getIdx11(),getIdx12(),getIdx13(),getIdx14(),getIdx15(),
                getIdx16(),getIdx17(),getIdx18(),getIdx19(),getIdx20(),getIdx21(),getIdx22(),getIdx23(),getIdx24(),
                getIdx25(),getIdx26(),getIdx27(),getIdx28(),getIdx29(),getIdx30()};
    }
    @Override
    public String toString() {
        return "MyData_2{" +
                "idx1='" + idx1 + '\'' +
                ", idx2='" + idx2 + '\'' +
                ", idx3='" + idx3 + '\'' +
                ", idx4='" + idx4 + '\'' +
                ", idx5='" + idx5 + '\'' +
                ", idx6='" + idx6 + '\'' +
                ", idx7='" + idx7 + '\'' +
                ", idx8='" + idx8 + '\'' +
                ", idx9='" + idx9 + '\'' +
                ", idx10='" + idx10 + '\'' +
                ", idx11='" + idx11 + '\'' +
                ", idx12='" + idx12 + '\'' +
                ", idx13='" + idx13 + '\'' +
                ", idx14='" + idx14 + '\'' +
                ", idx15='" + idx15 + '\'' +
                ", idx16='" + idx16 + '\'' +
                ", idx17='" + idx17 + '\'' +
                ", idx18='" + idx18 + '\'' +
                ", idx19='" + idx19 + '\'' +
                ", idx20='" + idx20 + '\'' +
                ", idx21='" + idx21 + '\'' +
                ", idx22='" + idx22 + '\'' +
                ", idx23='" + idx23 + '\'' +
                ", idx24='" + idx24 + '\'' +
                ", idx25='" + idx25 + '\'' +
                ", idx26='" + idx26 + '\'' +
                ", idx27='" + idx27 + '\'' +
                ", idx28='" + idx28 + '\'' +
                ", idx29='" + idx29 + '\'' +
                ", idx30='" + idx30 + '\'' +
                '}';
    }
}
