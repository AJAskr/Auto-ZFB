package com.mx.accessibilitydemo.ExcelUtli;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.read.builder.ExcelReaderBuilder;
import com.alibaba.excel.read.builder.ExcelReaderSheetBuilder;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Excel_To_Info_TXT {
    //解决方案A 创建info.txt并返回true

    /**
     *
     * @param headRowNumber 列表头索引
     * @param splitStr 其他电话的分隔符
     * @param col1 姓名
     * @param col2 电话
     * @param col3 更多电话
     * @param FilePath 表格路径
     * @param savaPath info文本文件保存路径
     * @return 成功返回true 失败返回false
     */
    public boolean PlanA(int headRowNumber,String splitStr, String col1, String col2, String col3, String FilePath ,String savaPath) {
        MyListener_formal listener_formal = new MyListener_formal();
        ExcelReaderBuilder read;
        try {
            read = EasyExcel.read(FilePath, MyData_formal.class, listener_formal).headRowNumber(headRowNumber);
        }catch (Exception e){
            return false;
        }
        ExcelReaderSheetBuilder sheet;
        try {
            sheet = read.sheet();
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
        sheet.doRead();
        //获取得到表头对应的列名的索引值存放在indexRES
        int[] indexRES = new int[]{-1,-1,-1};

        int cnt = 1;
        int cnt2 = 0;
        for (Map<Integer, String> i : listener_formal.getList2()) {
            if (cnt == headRowNumber) {
                for (int j = 0; j < i.size(); j++) {
                    if (cnt2<=2){
                        if (col1.equals(i.get(j))){
                            indexRES[cnt2++] = j;
                        }
                        if (col2.equals(i.get(j))){
                            indexRES[cnt2++] = j;
                        }
                        if (col3.equals(i.get(j))){
                            indexRES[cnt2++] = j;
                        }
                    }else {
                        break;
                    }
                }
            }
            cnt++;
        }

        //索引不对 直接返回false
        for (int i : indexRES){
            if (i == -1){
                return false;
            }
        }


        //开始处理表的信息
        List<MyData_formal> list= listener_formal.getList();
        List<String> res_List = new ArrayList<>();
        String tempStr = "";
        int idx = 1;
        for (MyData_formal i:list){
//            System.out.println(i.getAllData()[indexRES[0]] + " " + i.getAllData()[indexRES[1]] + i.getAllData()[indexRES[2]]);
            tempStr+=(idx++)+";";
            tempStr+=i.getAllData()[indexRES[0]] + ";";
            if ((!i.getAllData()[indexRES[1]].contains("-")) && (i.getAllData()[indexRES[1]].length()==11)){
                tempStr+=i.getAllData()[indexRES[1]] + ";";
            }
            String[] split = i.getAllData()[indexRES[2]].split(splitStr);
            for (String j : split){
                if ((!j.equals(i.getAllData()[indexRES[1]])) && (!j.contains("-")) && (j.length()==11)){
                    tempStr += j +";";
                }
            }
            if (tempStr.split(";").length==1){
                tempStr+="null"+";";
            }
            res_List.add(tempStr);
            tempStr = "";
        }

        //将res_List保存为文本
        File file = new File(savaPath);
        boolean yz = true;
        if (file.exists()){
            yz = file.delete();
        }
        if (!yz){
            return false;
        }
        try {
            boolean t = file.createNewFile();
            if (!t){
                return false;
            }
            FileWriter fw = new FileWriter(file);
            for (String i:res_List){
                fw.write(i+"\n");
                fw.flush();
            }
            fw.close();
        }catch (IOException Exception){
            return false;
        }

        //保存为提供最后一步处理的信息
        String advTxtPath = savaPath.split("\\.")[0]+"_adv.txt";
        file = new File(advTxtPath);
        boolean yz2 = true;
        if (file.exists()){
            yz2 = file.delete();
        }
        if (!yz2){
            return false;
        }
        try {
            boolean t2 = file.createNewFile();
            FileWriter fw = new FileWriter(file);
            fw.write(FilePath+"\n");
            fw.flush();
            fw.write(indexRES[0]+";"+indexRES[1]+";"+indexRES[2]+";"+"\n");
            fw.flush();
            fw.write(headRowNumber+";"+col1+";"+col2+";"+col3+";"+"\n");
            fw.flush();
            fw.close();
        }catch (Exception e){
            return false;
        }
        return true;
    }


    /**
     *
     * @param headRowNumber 列表头索引
     * @param splitStr 很多电话的分隔符
     * @param col1 姓名
     * @param col2 更多电话
     * @param FilePath 表格路径
     * @param savaPath 保存info.txt的路径
     * @return 成功返回true 失败返回false
     */
    //解决方案B
    public boolean PlanB(int headRowNumber,String splitStr, String col1, String col2, String FilePath ,String savaPath){
        MyListener_formal listener_formal = new MyListener_formal();
        ExcelReaderBuilder read;
        try {
            read = EasyExcel.read(FilePath, MyData_formal.class, listener_formal).headRowNumber(headRowNumber);
        }catch (Exception e){
            return false;
        }
        ExcelReaderSheetBuilder sheet = read.sheet();
        sheet.doRead();
        //获取得到表头对应的列名的索引值存放在indexRES
        int[] indexRES = new int[]{-1,-1};

        for (Map<Integer,String > i:listener_formal.getList2()){
            System.out.println(i);
        }

        int cnt = 1;
        int cnt2 = 0;
        for (Map<Integer, String> i : listener_formal.getList2()) {
            if (cnt == headRowNumber) {
                for (int j = 0; j < i.size(); j++) {
                    if (cnt2<=2){
                        if (col1.equals(i.get(j))){
                            indexRES[cnt2++] = j;
                        }
                        if (col2.equals(i.get(j))){
                            indexRES[cnt2++] = j;
                        }
                    }else {
                        break;
                    }
                }
            }
            cnt++;
        }

        //索引不对 直接返回false
        for (int i : indexRES){
            if (i == -1){
                return false;
            }
        }


        //开始处理表的信息
        List<MyData_formal> list= listener_formal.getList();
        List<String> res_List = new ArrayList<>();
        String tempStr = "";
        int idx = 1;
        for (MyData_formal i:list){
//            System.out.println(i.getAllData()[indexRES[0]] + " " + i.getAllData()[indexRES[1]] + i.getAllData()[indexRES[2]]);
            tempStr+=(idx++)+";";
            tempStr+=i.getAllData()[indexRES[0]] + ";";
            String[] split = i.getAllData()[indexRES[1]].split(splitStr);
            for (String j : split){
                if ((!j.contains("-")) && (j.length()==11)){
                    tempStr += j +";";
                }
            }
            if (tempStr.split(";").length==1){
                tempStr+="null"+";";
            }
            res_List.add(tempStr);
            tempStr = "";
        }

        //将res_List保存为文本
        File file = new File(savaPath);
        boolean yz = true;
        if (file.exists()){
            yz = file.delete();
        }
        if (!yz){
            return false;
        }
        try {
            boolean t = file.createNewFile();
            if (!t){
                return false;
            }
            FileWriter fw = new FileWriter(file);
            for (String i:res_List){
                fw.write(i+"\n");
                fw.flush();
            }
            fw.close();
        }catch (IOException Exception){
            return false;
        }

        //保存为提供最后一步处理的信息
        String advTxtPath = savaPath.split("\\.")[0]+"_adv.txt";
        file = new File(advTxtPath);
        boolean yz2 = true;
        if (file.exists()){
            yz2 = file.delete();
        }
        if (!yz2){
            return false;
        }
        try {
            boolean t2 = file.createNewFile();
            FileWriter fw = new FileWriter(file);
            fw.write(FilePath+"\n");
            fw.flush();
            fw.write(indexRES[0]+";"+indexRES[1]+";"+";"+"\n");
            fw.flush();
            fw.write(headRowNumber+";"+col1+";"+col2+";"+"\n");
            fw.flush();
            fw.close();
        }catch (Exception e){
            return false;
        }

        return true;
    }
}
